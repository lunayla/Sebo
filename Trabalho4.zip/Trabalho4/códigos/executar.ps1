param([Parameter(Mandatory=$true)][ValidateSet('compilar','broker','servidor','cliente')][string]$Acao)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if ($Acao -eq 'compilar') {
    if (Test-Path 'bin') { Remove-Item 'bin' -Recurse -Force }
    New-Item -ItemType Directory -Path 'bin' | Out-Null
    $arquivos = Get-ChildItem 'src' -Recurse -Filter '*.java' | ForEach-Object { $_.FullName }
    javac -encoding UTF-8 -d 'bin' $arquivos
    if ($LASTEXITCODE -ne 0) { throw 'Falha na compilação.' }
    Write-Host 'Compilação concluída.' -ForegroundColor Green
} elseif ($Acao -eq 'broker') {
    java -cp 'bin' broker.BrokerPubSubServer
} elseif ($Acao -eq 'servidor') {
    java -cp 'bin' server.ServidorSeboRMI
} elseif ($Acao -eq 'cliente') {
    java -cp 'bin' client.ClienteSeboRMI
}
