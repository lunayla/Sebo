package broker;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;
import java.util.Base64;

/** Broker Publish-Subscribe com tópicos, assinaturas duráveis e log persistente. */
public class BrokerPubSubServer {
    private static final int PORT = Integer.parseInt(System.getenv().getOrDefault("SEBO_BROKER_PORT", "5050"));
    private static final Path LOG = Paths.get("dados-pubsub", "broker.log");
    private final Object lock = new Object();
    private final Map<String, Set<String>> subscribersByTopic = new HashMap<>();
    private final Map<String, Event> events = new LinkedHashMap<>();
    private final Map<String, Set<String>> pendingBySubscriber = new HashMap<>();
    private final Map<String, Session> sessions = new ConcurrentHashMap<>();
    private final AtomicLong sequence = new AtomicLong(1);

    private static class Event {
        final String id, topic, payload;
        Event(String id, String topic, String payload) { this.id=id; this.topic=topic; this.payload=payload; }
    }
    private static class Session {
        final String subscriber;
        final BufferedWriter out;
        Session(String subscriber, BufferedWriter out) { this.subscriber=subscriber; this.out=out; }
        synchronized void send(String line) throws IOException { out.write(line); out.newLine(); out.flush(); }
    }

    public BrokerPubSubServer() throws IOException { Files.createDirectories(LOG.getParent()); replay(); }

    private void append(String record) throws IOException {
        Files.writeString(LOG, record + System.lineSeparator(), StandardCharsets.UTF_8,
                StandardOpenOption.CREATE, StandardOpenOption.APPEND);
    }

    private void replay() throws IOException {
        if (!Files.exists(LOG)) return;
        for (String line : Files.readAllLines(LOG, StandardCharsets.UTF_8)) {
            String[] p=line.split("\\|",4);
            try {
                switch(p[0]) {
                    case "SUB": subscribersByTopic.computeIfAbsent(dec(p[2]),k->new HashSet<>()).add(dec(p[1])); break;
                    case "PUB": {
                        String id=p[1], topic=dec(p[2]), payload=dec(p[3]);
                        events.put(id,new Event(id,topic,payload));
                        for(String sub: subscribersByTopic.getOrDefault(topic,Collections.emptySet()))
                            pendingBySubscriber.computeIfAbsent(sub,k->new LinkedHashSet<>()).add(id);
                        sequence.set(Math.max(sequence.get(),Long.parseLong(id)+1));
                        break;
                    }
                    case "ACK": pendingBySubscriber.computeIfAbsent(dec(p[1]),k->new LinkedHashSet<>()).remove(p[2]); break;
                }
            } catch(Exception ignored) { System.err.println("Registro ignorado no log: "+line); }
        }
        System.out.println("[Broker] Log recuperado. Eventos armazenados: "+events.size());
    }

    private static String enc(String s) { return Base64.getEncoder().encodeToString(s.getBytes(StandardCharsets.UTF_8)); }
    private static String dec(String s) { return new String(Base64.getDecoder().decode(s),StandardCharsets.UTF_8); }

    private void subscribe(String subscriber,String topic,Session session) throws IOException {
        synchronized(lock) {
            Set<String> subs=subscribersByTopic.computeIfAbsent(topic,k->new HashSet<>());
            if(subs.add(subscriber)) append("SUB|"+enc(subscriber)+"|"+enc(topic));
            sessions.put(subscriber,session);
            System.out.println("[Broker] SUBSCRIBE: "+subscriber+" -> "+topic);
            deliverPending(subscriber,session);
        }
    }

    private void publish(String topic,String payload) throws IOException {
        synchronized(lock) {
            String id=String.valueOf(sequence.getAndIncrement());
            append("PUB|"+id+"|"+enc(topic)+"|"+enc(payload));
            events.put(id,new Event(id,topic,payload));
            Set<String> subscribers=subscribersByTopic.getOrDefault(topic,Collections.emptySet());
            for(String subscriber:subscribers) {
                pendingBySubscriber.computeIfAbsent(subscriber,k->new LinkedHashSet<>()).add(id);
                Session s=sessions.get(subscriber);
                if(s!=null) {
                    try { deliverOne(subscriber,id,s); }
                    catch(IOException ex) { sessions.remove(subscriber); System.out.println("[Broker] Assinante desconectou durante entrega; evento mantido pendente: "+subscriber); }
                }
            }
            System.out.println("[Broker] PUBLISH evento="+id+" tópico="+topic+" destinatários="+subscribers.size());
        }
    }

    private void deliverPending(String subscriber,Session s) {
        for(String id:new ArrayList<>(pendingBySubscriber.getOrDefault(subscriber,Collections.emptySet()))) {
            try { deliverOne(subscriber,id,s); }
            catch(IOException ex) { sessions.remove(subscriber); System.out.println("[Broker] Assinante desconectou; evento continuará pendente: "+subscriber); break; }
        }
    }
    private void deliverOne(String subscriber,String id,Session s) throws IOException {
        Event e=events.get(id); if(e==null) return;
        s.send("EVENT|"+id+"|"+enc(e.topic)+"|"+enc(e.payload));
    }
    private void ack(String subscriber,String id) throws IOException {
        synchronized(lock) {
            Set<String> pending=pendingBySubscriber.get(subscriber);
            if(pending!=null && pending.remove(id)) append("ACK|"+enc(subscriber)+"|"+id);
        }
    }

    private void handle(Socket socket) {
        String subscriber=null;
        try(socket;
            BufferedReader in=new BufferedReader(new InputStreamReader(socket.getInputStream(),StandardCharsets.UTF_8));
            BufferedWriter out=new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(),StandardCharsets.UTF_8))) {
            String line;
            while((line=in.readLine())!=null) {
                String[] p=line.split("\\|",4);
                if("SUB".equals(p[0]) && p.length>=3) {
                    subscriber=dec(p[1]); Session session=new Session(subscriber,out); subscribe(subscriber,dec(p[2]),session); session.send("OK|SUBSCRIBED");
                } else if("PUB".equals(p[0]) && p.length>=3) {
                    publish(dec(p[1]),dec(p[2])); out.write("OK|PUBLISHED\n"); out.flush();
                } else if("ACK".equals(p[0]) && p.length>=2 && subscriber!=null) {
                    ack(subscriber,p[1]);
                }
            }
        } catch(Exception e) {
            if(subscriber!=null) { synchronized(lock) { sessions.remove(subscriber); } System.out.println("[Broker] Assinante offline: "+subscriber+" (eventos pendentes preservados)"); }
        }
    }

    public void start() throws IOException {
        try(ServerSocket server=new ServerSocket(PORT)) {
            System.out.println("============================================");
            System.out.println(" Broker Publish-Subscribe ativo na porta "+PORT);
            System.out.println(" Tópicos, assinaturas duráveis e retenção habilitados");
            System.out.println("============================================");
            while(true) { Socket s=server.accept(); Thread t=new Thread(()->handle(s)); t.setDaemon(true); t.start(); }
        }
    }
    public static void main(String[] args) throws Exception { new BrokerPubSubServer().start(); }
}
