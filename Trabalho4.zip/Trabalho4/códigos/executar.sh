#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
case "$1" in
  compilar)
    rm -rf bin && mkdir -p bin
    find src -name '*.java' -print0 | xargs -0 javac -encoding UTF-8 -d bin
    echo 'Compilação concluída.' ;;
  broker) java -cp bin broker.BrokerPubSubServer ;;
  servidor) java -cp bin server.ServidorSeboRMI ;;
  cliente) java -cp bin client.ClienteSeboRMI ;;
  *) echo 'Uso: ./executar.sh {compilar|broker|servidor|cliente}'; exit 1 ;;
esac
